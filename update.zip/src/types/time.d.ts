export interface TimeList {
    value: string,
    label: string,
};