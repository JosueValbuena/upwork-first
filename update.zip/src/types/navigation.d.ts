export interface NavigationLink {
    label: string,
    path: string,
    icon: string
};