export interface CurrencyList {
    value: string,
    label: string,
};