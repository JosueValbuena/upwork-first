import {
    BusinessOverview,
    InventoryByBrand,
    LinearHorizontalChartSalesOverview,
} from "@/components/organism";
/* @ts-ignore */
import { closestCenter, DndContext, DragEndEvent } from "@dnd-kit/core";
import {
    SortableContext,
    verticalListSortingStrategy,
    useSortable,
    arrayMove
} from "@dnd-kit/sortable";
import { CSS } from "@dnd-kit/utilities";
import React, { useEffect, useState } from "react";
import DashboardSectionOne from './sections-one/SectionOne';
import DashboardSectionTwo from './sections-two/SectionTwo';
import { useAppSelector } from "@/store/hooks";

const SortableItem = ({ id, children }: { id: string, children: React.ReactNode }) => {

    const { attributes, listeners, setNodeRef, transform, transition } = useSortable({ id });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
    };

    return (
        <div
            ref={setNodeRef}
            style={style}
            {...attributes}
            {...listeners}
        >
            {children}
        </div>
    );
};

const Dashboard = () => {

    const { value: isSortMode } = useAppSelector(state => state.sortMode);

    /* @ts-ignore */
    const componentsMap: Record<string, JSX.Element> = {
        BusinessOverview: <BusinessOverview />,
        SalesOverview: <LinearHorizontalChartSalesOverview />,
        InventoryGroup1: <DashboardSectionOne />,
        InventoryGroup2: <DashboardSectionTwo />,
        InventoryByBrand: <InventoryByBrand />
    };

    const [componentOrder, setComponentOrder] = useState<string[]>([]);

    const handleDragEnd = (event: DragEndEvent) => {
        const { active, over } = event;

        if (active.id !== over?.id) {
            setComponentOrder((prev) => {
                const oldIndex = prev.indexOf(active.id as string);
                const newIndex = prev.indexOf(over?.id as string);
                return arrayMove(prev, oldIndex, newIndex);
            });
        };
    };

    useEffect(() => {
        const storedValue = localStorage.getItem('draggedUserPreference');
        const draggedUserPreferences = storedValue ? JSON.parse(storedValue) : {};
        if (draggedUserPreferences?.dashboardGeneralLayout) {
            setComponentOrder(draggedUserPreferences?.dashboardGeneralLayout);
            return
        };

        if (!draggedUserPreferences?.dashboardGeneralLayout) {
            setComponentOrder([
                "BusinessOverview",
                "SalesOverview",
                "InventoryGroup1",
                "InventoryGroup2",
                "InventoryByBrand"
            ])
        };
    }, []);

    useEffect(() => {
        if (componentOrder.length > 1) {

            const storedValue = localStorage.getItem('draggedUserPreference');
            const draggedUserPreferences = storedValue ? JSON.parse(storedValue) : {};
            let newDraggedUserPreferences = {
                ...draggedUserPreferences,
                dashboardGeneralLayout: componentOrder
            };

            localStorage.setItem('draggedUserPreference', JSON.stringify(newDraggedUserPreferences));
        }
    }, [componentOrder]);

    return (
        <div className={`bg-background-primary-customized `}>

            {isSortMode ? (
                <DndContext
                    collisionDetection={closestCenter}
                    onDragEnd={handleDragEnd}
                >
                    <SortableContext
                        items={componentOrder}
                        strategy={verticalListSortingStrategy}
                    >
                        {componentOrder.map((id) => (
                            <SortableItem key={id} id={id}>
                                {componentsMap[id]}
                            </SortableItem>
                        ))}
                    </SortableContext>
                </DndContext>
            ) : (
                <>
                    {componentOrder.map((id) => (
                        <React.Fragment key={id}>
                            {componentsMap[id]}
                        </React.Fragment>
                    ))}
                </>
            )}
        </div>
    );
};

export default Dashboard;