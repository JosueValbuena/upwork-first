import { useAppSelector } from "@/store/hooks";
import ReactApexChart from "react-apexcharts";

const ChartsBar = () => {

    const { theme } = useAppSelector(state => state.themeMode);

    const series = [{
        name: 'TEAM A',
        type: 'column',
        data: [23, 11, 22, 27, 13, 22, 37, 21, 44, 22, 30]
    }, {
        name: 'TEAM B',
        type: 'area',
        data: [44, 55, 41, 67, 22, 43, 21, 41, 56, 27, 43]
    }, {
        name: 'TEAM C',
        type: 'line',
        data: [30, 25, 36, 30, 45, 35, 64, 52, 59, 36, 39]
    }];

    const options = {
        chart: {
            height: 350,
            type: 'line',
            stacked: false,
        },
        stroke: {
            width: [0, 2, 5],
            curve: 'smooth'
        },
        plotOptions: {
            bar: {
                columnWidth: '50%'
            }
        },

        fill: {
            opacity: [0.85, 0.25, 1],
            gradient: {
                inverseColors: false,
                shade: 'light',
                type: "vertical",
                opacityFrom: 0.85,
                opacityTo: 0.55,
                stops: [0, 100, 100, 100]
            }
        },
        labels: ['01/01/2003', '02/01/2003', '03/01/2003', '04/01/2003', '05/01/2003', '06/01/2003', '07/01/2003',
            '08/01/2003', '09/01/2003', '10/01/2003', '11/01/2003'
        ],
        markers: {
            size: 0
        },
        xaxis: {
            type: 'datetime',
            labels: {
                style: {
                    colors: theme === 'light' ? '#000' : '#fff',
                }
            },
        },
        yaxis: [
            {
                seriesName: 'TEAM A',
                axisTicks: {
                    show: true,
                },
                axisBorder: {
                    show: true,
                    color: '#000'
                },
                labels: {
                    style: {
                        colors: theme === 'light' ? '#000' : '#fff',
                    }
                },
                /* title: {
                    text: "Income (thousand crores)",
                    style: {
                        color: '#008FFB',
                    }
                },  */
                tooltip: {
                    enabled: true
                }
            },
            {
                seriesName: 'TEAM B',
                opposite: true,
                axisTicks: {
                    show: true,
                },
                axisBorder: {
                    show: true,
                    color: '#000'
                },
                labels: {
                    style: {
                        colors: theme === 'light' ? '#000' : '#fff',
                    }
                },
                /* title: {
                    text: "Operating Cashflow (thousand crores)",
                    style: {
                        color: '#00E396',
                    }
                }, */
            },
            /*{
               title: {
                   text: 'Points',
               } 
           }*/
        ],
        tooltip: {
            shared: true,
            intersect: false,
            y: {
                formatter: function (y: any) {
                    if (typeof y !== "undefined") {
                        return y.toFixed(0) + " points";
                    }
                    return y;

                }
            }
        },
        legend: {
            show: false
        }
    };

    return (
        <div>
            <div id="chart">
                <ReactApexChart
                    // @ts-ignore
                    options={options}
                    series={series}
                    type="line"
                    height={350} />
            </div>
            <div id="html-dist"></div>
        </div>
    );
}

export default ChartsBar;